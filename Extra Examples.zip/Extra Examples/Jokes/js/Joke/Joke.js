class Joke{
    constructor(id, category, setup, delivery) {
        this.id = id;
        this.category = category;
        this.setup =setup;
        this.delivery = delivery;
    }
}