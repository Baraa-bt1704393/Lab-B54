export class Census {
    constructor(id, country, population) {
        this.id = id;
        this.country = country;
        this.population = population;
    }
}